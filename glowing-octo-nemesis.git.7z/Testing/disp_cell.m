function disp_cell(x)

for i = 1:length(x)
    x{i,1}
end