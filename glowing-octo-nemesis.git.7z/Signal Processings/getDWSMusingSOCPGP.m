
% function [basePrecoders] = getDWSMusingSOCPGP(SimParams,SimStructs,cGene)

load GeneticStructures;

SimParams = GenStruct.SimParams;
SimStructs = GenStruct.SimStructs;




