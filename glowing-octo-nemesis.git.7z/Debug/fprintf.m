function fprintf(varargin)

end